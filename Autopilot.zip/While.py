alpha, Fpx = 0, 0
alphaList = []
alphaList.append(alpha)

alpha = alpha_0 + Cz_eq/C_zalpha - Cz_deltam/C_zalpha*dela_meq
alphaList.append(alpha)
Fpx = Q*S*Cx_eq/(np.cos(alpha))
i = 1
epsilon = 0.00000000000000000000001
while abs(alphaList[i] - alphaList[i-1])>epsilon:
    Cz_eq = 1/(Q*S)*(m*g0-Fpx*np.sin(alpha))
    Cx_eq = C_x0 + k*pow(Cz_eq, 2)
    Cx_deltam = 2*k*Cz_eq*Cz_deltam
    delta_meq = delta_m0 -(Cx_eq*np.sin(alpha) + Cz_eq*np.cos(alpha))/(Cx_deltam*np.sin(alpha)+Cz_deltam*np.cos(alpha))
    dela_meq = delta_meq*(X/(Y-X))

    alpha = alpha_0 + Cz_eq/C_zalpha - Cz_deltam/C_zalpha*dela_meq
    alphaList.append(alpha)
    Fpx = Q*S*Cx_eq/(np.cos(alpha))
    i +=1